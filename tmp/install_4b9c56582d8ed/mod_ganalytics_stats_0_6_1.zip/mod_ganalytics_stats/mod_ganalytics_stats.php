<?php
/**
 * GAnalytics is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GAnalytics is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GAnalytics.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @author Allon Moritz
 * @copyright 2007-2010 Allon Moritz
 * @version $Revision: 0.6.1 $
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

require_once(dirname(__FILE__).DS.'helper.php');
require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ganalytics'.DS.'util'.DS.'util.php');
require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ganalytics'.DS.'util'.DS.'dbutil.php');
require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ganalytics'.DS.'util'.DS.'listutil.php');
if (file_exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ganalytics'.DS.'util'.DS.'proutil.php')) {
	require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ganalytics'.DS.'util'.DS.'proutil.php');
}
if (file_exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ganalytics'.DS.'util'.DS.'chartutil.php')) {
	require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ganalytics'.DS.'util'.DS.'chartutil.php');
}
jimport('simplepie.simplepie');
require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ganalytics'.DS.'libraries'.DS.'sp-ganalytics'.DS.'simplepie-ganalytics.php' );


$feed = ModGAnalyticsStatsHelper::getSelectedAccount($params);
if($feed == null)return;

$dateFormat = $params->get('dateFormat', '%d.%m.%Y');
$title = $params->get('titleFormat', '');
$title = str_replace("{accountname}", $feed->get('ga_accountName'), $title);
$title = str_replace("{profilename}", $feed->get('ga_profileName'), $title);
$title = str_replace("{startdate}", strftime($dateFormat, $feed->get_start_date()), $title);
$title = str_replace("{dateseparator}", '-', $title);
$title = str_replace("{endate}", strftime($dateFormat, $feed->get_end_date()), $title);
$title = str_replace("{dimension}", JText::_(substr($feed->get_dimensions(), 3)), $title);
$title = str_replace("{metric}", JText::_(substr($feed->get_metrics(), 3)), $title);
$width = $params->get('width', '200px');
$height = $params->get('height', '200px');
$color = $params->get('color', null);

$mode = $params->get('mode', 'list');
if(!class_exists('GAnalyticsProUtil'))
$mode = 'list';

require( JModuleHelper::getLayoutPath('mod_ganalytics_stats',  $mode) );
?>