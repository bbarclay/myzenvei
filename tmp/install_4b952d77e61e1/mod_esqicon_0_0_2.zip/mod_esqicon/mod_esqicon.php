<?php
/**
 * @module      Easy Search Quick Icon
 * @copyright   Copyright (C) 2009 Hiro Nozu
 * @license     GNU/GPL
 * @website     http://easysearch.forjoomla.net/
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

if (!defined( '_JOS_QUICKICONES_MODULE' ))
{
    /** ensure that functions are declared only once */
    define( '_JOS_QUICKICONES_MODULE', 1 );

    function quickiconButtonEs( $link, $image, $text )
    {
        global $mainframe;
        $lang =& JFactory::getLanguage();
        ?>
        <div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
            <div class="icon">
                <a href="<?php echo $link; ?>">
                    <?php echo JHTML::_('image.site',  $image, '/modules/mod_esqicon/', NULL, NULL, $text ); ?>
                    <span><?php echo $text; ?></span></a>
            </div>
        </div>
        <?php
    }

    ?>
    <div id="cpanel">
        <?php
        $link = 'index.php?option=com_easysearch';
        quickiconButtonEs( $link, 'icon-48-easysearch.png', JText::_( 'Easy Search' ) );
        ?>
    </div>
    <?php
}