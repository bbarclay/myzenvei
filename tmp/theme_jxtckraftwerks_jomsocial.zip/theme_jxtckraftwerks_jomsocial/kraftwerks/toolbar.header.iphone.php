<?php
/*
<div class="toolbar-box-l">
	<div class="toolbar-box-r">
		<div class="<?php echo $style; ?> toolbar-icon-front"><?php echo $title; ?></div>
	</div>
</div>
*/
?>
