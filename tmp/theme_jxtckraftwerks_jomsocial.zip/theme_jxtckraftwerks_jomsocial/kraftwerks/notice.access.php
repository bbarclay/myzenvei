<div class="app-box-header">
<div class="app-box-header">
	<h2 class="app-box-title"></h2>
</div>
</div>
<div class="app-box-content">
<?php echo JText::_('CC NOT ALLOWED TO VIEW PAGE');?> 
<?php echo JText::sprintf('CC NOTICE NO ACCESS' , CRoute::_('index.php?option=com_community&view=frontpage') , CRoute::_('index.php?option=com_community&view=register') );?>
</div>
<div class="app-box-footer"><div class="app-box-footer"></div></div>