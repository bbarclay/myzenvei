Hi {target},

<?php echo $creator->getDisplayName(); ?> has recently posted a new discussion in the group <?php echo $group->name; ?>. Below is the discussion snippet that has been created.  

Subject:
<?php echo $subject; ?>

Message:
<?php echo $message; ?>


To post a reply, you may visit the site at <?php echo $url; ?>

Have a nice day!
