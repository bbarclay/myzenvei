Hi {target},

{actor} invited you to join a group (<?php echo $groupname;?>). Below is a message that is sent by {actor},

Message:

<?php echo $message; ?>

To view the group, access the URL at the following location:

<?php echo $url; ?>


Have a nice day!

