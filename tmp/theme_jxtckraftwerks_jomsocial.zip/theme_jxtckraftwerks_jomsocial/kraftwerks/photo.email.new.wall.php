Hi {target},

<?php echo $user->getDisplayName(); ?> just posted a wall message. 

Message:

<?php echo $message; ?>

You can read the message at:


<?php echo $url; ?>


Have a nice day!

