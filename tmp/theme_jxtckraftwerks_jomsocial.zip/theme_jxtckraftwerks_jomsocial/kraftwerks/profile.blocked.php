<div class="app-box-header">
<div class="app-box-header">
	<h2 class="app-box-title"></h2>
</div>
</div>
<div class="app-box-content">
	<?php echo JText::_('CC USER ACCOUNT IS BLOCKED');?>
</div>
<div class="app-box-footer"><div class="app-box-footer"></div></div>