Hi {target},

{actor} tagged you in a photo.  To view this photo, please click the link below:

<?php echo $url; ?>


Have a nice day!
