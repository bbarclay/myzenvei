<?php
/*
<div class="toolbar-box-l">
	<div class="toolbar-box-r">
		<div class="<?php echo $style; ?> toolbar-icon-front"><?php echo $title; ?></div>
	</div>
</div>
*/
?>                        
   <div class="box componenthead">
       <div class="box_left_title">
           <div class="box_right_title">
               <h1 class="pagetitle">
				<?php echo $title; ?>  
               </h1>    
           </div>
       </div>
   </div>