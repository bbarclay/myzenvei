Hi {target},

{actor} just sent you a new message.

You can read your new message here:

<?php echo $url; ?>


Have a nice day!


