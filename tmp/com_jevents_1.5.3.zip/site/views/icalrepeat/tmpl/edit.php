<?php 
defined('_JEXEC') or die('Restricted access');

include_once(JEV_ADMINPATH."/views/icalrepeat/tmpl/".basename(__FILE__));
