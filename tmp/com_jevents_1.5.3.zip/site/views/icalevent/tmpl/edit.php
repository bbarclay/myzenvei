<?php 
defined('_JEXEC') or die('Restricted access');

include_once(JEV_ADMINPATH."/views/icalevent/tmpl/".basename(__FILE__));
