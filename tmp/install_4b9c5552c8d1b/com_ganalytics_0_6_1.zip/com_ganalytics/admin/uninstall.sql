DROP TABLE IF EXISTS `#__ganalytics`;
