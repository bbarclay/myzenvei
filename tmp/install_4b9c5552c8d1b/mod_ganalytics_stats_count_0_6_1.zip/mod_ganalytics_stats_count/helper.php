<?php
/**
 * GAnalytics is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GAnalytics is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GAnalytics.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @author Allon Moritz
 * @copyright 2007-2010 Allon Moritz
 * @version $Revision: 0.6.1 $
 */

defined('_JEXEC') or die('Restricted access');

class ModGAnalyticsStatsCountHelper {

	function getSelectedFeeds(&$params) {
		$accountids = $params->get('accountids');
		$accountId = null;
		if(!empty($accountids)){
			if(is_array($accountids)) {
				$accountId = $accountids[0];
			} else {
				$accountId = $accountids;
			}
		}else {
			$accountids = GAnalyticsDBUtil::getAllAccounts();
			if(!empty($accountids)){
				$accountId = $accountids[0]->id;
			}
		}
		if($accountId == null){
			JError::raiseWarning( 0, 'Mod GAnalytics Stats count was unable to load data, no account was available!!');
			return null;
		}

		$feeds = array();
		if($params->get('selectTotalVisitors', 'yes') == 'yes'){
			$feed = ModGAnalyticsStatsCountHelper::createFeed($accountId, $params, 'ga:year', 'ga:visits', 1000, '');
			$feed->put('mod_type', 'selectTotalVisitors');
			$feeds[] = 	$feed;
		}
		if($params->get('selectVisitorsDay', 'yes') == 'yes'){
			$feed = ModGAnalyticsStatsCountHelper::createFeed($accountId, $params, 'ga:date', 'ga:visits', 10000, '');
			$feed->put('mod_type', 'selectVisitorsDay');
			$feeds[] = 	$feed;
		}
		return $feeds;
	}

	function createFeed($accountId, $params, $dimensions, $metrics, $max, $sort) {
		$feed = GAnalyticsUtil::getAnalyticsHandler($accountId);
		$feed->set_start_date($feed->get('ga_startDate'));
		$feed->set_end_date(time());
		$max =  $params->get('max', 1000);
		$feed->set_parameters($dimensions, $metrics, $max, $sort);
		GAnalyticsUtil::configureCache($feed, $params, 'mod_ganalytics_stats_count');
		$feed->init();
		if($feed->error()) {
//			JError::raiseWarning( 500, 'An error occured fetching the data!! Here is the output: '.$feed->error());
		}
		return $feed;
	}
}
?>
