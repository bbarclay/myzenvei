<div style="border:1px solid #FF0000; padding:20px; background-color:#FFEAEA">
<?php echo JText::_('CC NOT ALLOWED TO VIEW PAGE');?>
</div>

<p><?php echo JText::sprintf('CC NOTICE NO ACCESS' , CRoute::_('index.php?option=com_community&view=frontpage') , CRoute::_('index.php?option=com_community&view=register') );?></p>