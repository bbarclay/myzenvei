Hi {target},

<?php echo $group->name; ?> group just posted a new bulletin. 

Subject: <?php echo $subject; ?>


You can read your new message here:


<?php echo $url; ?>


Have a nice day!

