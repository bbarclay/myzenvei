<?php
defined('_JEXEC') or die();
?>
success