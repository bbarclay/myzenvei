Hi {target},

A reported item has reached its threshold and the default action has been executed. The location of the reported item may be found below,

URL: <?php echo $url; ?>

