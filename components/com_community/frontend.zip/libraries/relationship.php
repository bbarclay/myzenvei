<?php
/**
 * @package		JomSocial
 * @subpackage	Core 
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license http://www.jomsocial.com Copyrighted Commercial Software
 */
 
class CommunityRelationshipLib {
	
	/**
	 * Get the relationship status of 2 given user
	 * @param 	int	user id
	 * @param 	int	user id
	 * @return	int	status id	 	 	 
	 */	 	
	function getStatus($user1, $user2){
	} 
}
