<?php
// Disallow direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<h3 style="text-decoration: underline;"><?php echo JText::_('CC APPLICATIONS');?></h3>
<p>
Applications in Jom Social are installed via <strong>Joomla!'s Plugin Manager</strong>. This is to allow developers
to easily develop their own set of applications easily and allows end user to install them at 1 single location.
</p>
<div>
<a href="index.php?option=com_plugins&filter_type=community">Click here to view the applications lists</a>
</div>